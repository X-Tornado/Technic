For single player mode only (does not require ModLoaderMP to be installed) rename XieBaseMod.class.SSP.bkp to XieBaseMod.class, and replace the same file in /mods/Xie.

For SMP mode, which works for both single and multiplayer, but requires ModLoaderMP to be installed, rename XieBaseMod.class.SMP.bkp to XieBaseMod.class, and replace the same file in /mods/Xie.